import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Cart - holds items a customer is about to order.
 *  - ArrayList for ordered storage / iteration
 *  - Deque used as a Stack to support "undo last add" (LIFO)
 */
public class Cart {
    private final List<FoodItem> items = new ArrayList<>();
    private final Deque<FoodItem> undoStack = new ArrayDeque<>();

    public void addItem(FoodItem item) {
        items.add(item);
        undoStack.push(item);
    }

    /** Removes the most recently added item. Returns null if cart is empty. */
    public FoodItem undoLastAdd() {
        if (undoStack.isEmpty()) return null;
        FoodItem last = undoStack.pop();
        // remove the most recent matching occurrence
        for (int i = items.size() - 1; i >= 0; i--) {
            if (items.get(i) == last) {
                items.remove(i);
                break;
            }
        }
        return last;
    }

    public List<FoodItem> getItems() {
        return new ArrayList<>(items);
    }

    public double getTotal() {
        double sum = 0;
        for (FoodItem f : items) sum += f.getPrice();
        return sum;
    }

    public void clear() {
        items.clear();
        undoStack.clear();
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }
}
