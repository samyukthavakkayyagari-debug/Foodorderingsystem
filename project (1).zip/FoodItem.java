/**
 * FoodItem - represents a single menu item.
 */
public class FoodItem {
    private final String id;
    private final String name;
    private final String category;
    private double price;
    private double rating; // out of 5

    public FoodItem(String id, String name, String category, double price, double rating) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.price = price;
        this.rating = rating;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public double getPrice() { return price; }
    public double getRating() { return rating; }

    public void setPrice(double price) { this.price = price; }
    public void setRating(double rating) { this.rating = rating; }

    @Override
    public String toString() {
        return String.format("[%s] %-20s | %-10s | Rs.%-8.2f | %.1f*",
                id, name, category, price, rating);
    }
}
