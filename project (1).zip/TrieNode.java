import java.util.HashMap;
import java.util.Map;

/**
 * TrieNode - building block for the Trie used in food-name autocomplete.
 */
public class TrieNode {
    Map<Character, TrieNode> children = new HashMap<>();
    boolean isEndOfWord = false;
    String fullWord = null; // stored at end node for quick retrieval
}
