import java.util.List;
import java.util.Scanner;

/**
 * Main - console entry point for the Food Ordering System.
 *
 * DSA concepts demonstrated:
 *   1. HashMap        -> MenuManager (O(1) item lookup by id)
 *   2. Trie            -> MenuManager (prefix search / autocomplete)
 *   3. Merge Sort       -> MenuManager (sort menu by price / rating)
 *   4. Binary Search    -> MenuManager (find cheapest item >= a price)
 *   5. ArrayList + Stack -> Cart (add items, undo last add)
 *   6. Priority Queue   -> OrderProcessor (express orders served first)
 *   7. Queue (LinkedList)-> OrderProcessor (completed-order history, FIFO)
 */
public class Main {
    private static final MenuManager menu = new MenuManager();
    private static final Cart cart = new Cart();
    private static final OrderProcessor processor = new OrderProcessor();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        seedMenu();
        boolean running = true;
        while (running) {
            printMenuOptions();
            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1": viewMenu(); break;
                case "2": searchByName(); break;
                case "3": sortMenu(); break;
                case "4": binarySearchPrice(); break;
                case "5": addToCart(); break;
                case "6": undoCart(); break;
                case "7": viewCart(); break;
                case "8": checkout(); break;
                case "9": processNextOrder(); break;
                case "10": viewOrderQueue(); break;
                case "0": running = false; break;
                default: System.out.println("Invalid choice. Try again.");
            }
        }
        System.out.println("Goodbye!");
    }

    private static void printMenuOptions() {
        System.out.println("\n===== FOOD ORDERING SYSTEM =====");
        System.out.println("1.  View full menu");
        System.out.println("2.  Search food by name (Trie prefix search)");
        System.out.println("3.  Sort menu (Merge Sort: price / rating)");
        System.out.println("4.  Find cheapest item >= price (Binary Search)");
        System.out.println("5.  Add item to cart");
        System.out.println("6.  Undo last cart addition (Stack)");
        System.out.println("7.  View cart");
        System.out.println("8.  Checkout (place order)");
        System.out.println("9.  Kitchen: process next order (Priority Queue)");
        System.out.println("10. View pending order queue");
        System.out.println("0.  Exit");
        System.out.print("Choose: ");
    }

    private static void seedMenu() {
        menu.addItem(new FoodItem("F1", "Margherita Pizza", "Pizza", 249.0, 4.5));
        menu.addItem(new FoodItem("F2", "Farmhouse Pizza", "Pizza", 329.0, 4.3));
        menu.addItem(new FoodItem("F3", "Veg Burger", "Burger", 99.0, 4.0));
        menu.addItem(new FoodItem("F4", "Paneer Tikka Burger", "Burger", 149.0, 4.6));
        menu.addItem(new FoodItem("F5", "Masala Dosa", "South Indian", 89.0, 4.7));
        menu.addItem(new FoodItem("F6", "Chicken Biryani", "Rice", 249.0, 4.8));
        menu.addItem(new FoodItem("F7", "Veg Biryani", "Rice", 199.0, 4.2));
        menu.addItem(new FoodItem("F8", "Cold Coffee", "Beverage", 79.0, 4.1));
        menu.addItem(new FoodItem("F9", "Gulab Jamun", "Dessert", 59.0, 4.4));
        menu.addItem(new FoodItem("F10", "Chocolate Brownie", "Dessert", 109.0, 4.6));
    }

    private static void viewMenu() {
        System.out.println("\n--- Full Menu ---");
        for (FoodItem f : menu.getAll()) System.out.println(f);
    }

    private static void searchByName() {
        System.out.print("Enter name prefix: ");
        String prefix = sc.nextLine().trim();
        List<String> matches = menu.autocomplete(prefix);
        if (matches.isEmpty()) {
            System.out.println("No matches found.");
        } else {
            System.out.println("Matches: " + matches);
        }
    }

    private static void sortMenu() {
        System.out.print("Sort by (1) Price  (2) Rating: ");
        String c = sc.nextLine().trim();
        List<FoodItem> sorted = c.equals("2") ? menu.sortedByRating() : menu.sortedByPrice();
        System.out.println("\n--- Sorted Menu ---");
        for (FoodItem f : sorted) System.out.println(f);
    }

    private static void binarySearchPrice() {
        System.out.print("Enter minimum price: ");
        double p;
        try {
            p = Double.parseDouble(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number.");
            return;
        }
        FoodItem found = menu.binarySearchByMinPrice(p);
        System.out.println(found == null
                ? "No item found at or above that price."
                : "Cheapest item >= " + p + ": " + found);
    }

    private static void addToCart() {
        System.out.print("Enter item id (e.g. F1): ");
        String id = sc.nextLine().trim();
        FoodItem item = menu.getById(id);
        if (item == null) {
            System.out.println("No such item.");
            return;
        }
        cart.addItem(item);
        System.out.println("Added: " + item.getName());
    }

    private static void undoCart() {
        FoodItem removed = cart.undoLastAdd();
        System.out.println(removed == null
                ? "Cart is already empty."
                : "Removed last added item: " + removed.getName());
    }

    private static void viewCart() {
        System.out.println("\n--- Cart ---");
        if (cart.isEmpty()) {
            System.out.println("(empty)");
            return;
        }
        for (FoodItem f : cart.getItems()) System.out.println(f);
        System.out.printf("Total: Rs.%.2f%n", cart.getTotal());
    }

    private static void checkout() {
        if (cart.isEmpty()) {
            System.out.println("Cart is empty — add items first.");
            return;
        }
        System.out.print("Your name: ");
        String name = sc.nextLine().trim();
        System.out.print("Express delivery? (y/n): ");
        boolean express = sc.nextLine().trim().equalsIgnoreCase("y");

        Order order = new Order(name, cart.getItems(), express);
        processor.placeOrder(order);
        cart.clear();
        System.out.println("Order placed: " + order);
    }

    private static void processNextOrder() {
        Order next = processor.processNext();
        System.out.println(next == null ? "No pending orders." : "Now preparing: " + next);
    }

    private static void viewOrderQueue() {
        System.out.println("\n--- Pending Orders (priority order) ---");
        List<Order> pending = processor.peekPendingOrder();
        if (pending.isEmpty()) {
            System.out.println("(none)");
        } else {
            pending.stream()
                   .sorted()
                   .forEach(System.out::println);
        }
    }
}
