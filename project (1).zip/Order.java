import java.util.List;

/**
 * Order - represents a placed customer order.
 * Implements Comparable so it can sit in a PriorityQueue
 * (express orders first, then earlier orders first).
 */
public class Order implements Comparable<Order> {
    private static int counter = 1000;

    private final int orderId;
    private final String customerName;
    private final List<FoodItem> items;
    private final double total;
    private final boolean express;
    private final long placedAt; // nano timestamp, used as tiebreaker

    public Order(String customerName, List<FoodItem> items, boolean express) {
        this.orderId = ++counter;
        this.customerName = customerName;
        this.items = items;
        this.express = express;
        this.placedAt = System.nanoTime();
        double sum = 0;
        for (FoodItem f : items) sum += f.getPrice();
        this.total = sum;
    }

    public int getOrderId() { return orderId; }
    public String getCustomerName() { return customerName; }
    public List<FoodItem> getItems() { return items; }
    public double getTotal() { return total; }
    public boolean isExpress() { return express; }
    public long getPlacedAt() { return placedAt; }

    @Override
    public int compareTo(Order other) {
        // Express orders always rank higher (lower compareTo value = higher priority)
        if (this.express != other.express) {
            return this.express ? -1 : 1;
        }
        // Otherwise, earlier order wins (FIFO within same priority tier)
        return Long.compare(this.placedAt, other.placedAt);
    }

    @Override
    public String toString() {
        return String.format("Order #%d | %s | %s | Items: %d | Total: Rs.%.2f",
                orderId, customerName, express ? "EXPRESS" : "REGULAR", items.size(), total);
    }
}
