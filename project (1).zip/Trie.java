import java.util.ArrayList;
import java.util.List;

/**
 * Trie - supports fast prefix-based search / autocomplete over food names.
 * Insert: O(L)   Search-prefix: O(L + results)   where L = word length.
 */
public class Trie {
    private final TrieNode root = new TrieNode();

    public void insert(String word) {
        TrieNode node = root;
        String lower = word.toLowerCase();
        for (char c : lower.toCharArray()) {
            node = node.children.computeIfAbsent(c, k -> new TrieNode());
        }
        node.isEndOfWord = true;
        node.fullWord = word;
    }

    /** Returns all inserted words that start with the given prefix. */
    public List<String> searchByPrefix(String prefix) {
        List<String> results = new ArrayList<>();
        TrieNode node = root;
        String lower = prefix.toLowerCase();
        for (char c : lower.toCharArray()) {
            node = node.children.get(c);
            if (node == null) return results; // no matches
        }
        collectWords(node, results);
        return results;
    }

    private void collectWords(TrieNode node, List<String> results) {
        if (node.isEndOfWord) results.add(node.fullWord);
        for (TrieNode child : node.children.values()) {
            collectWords(child, results);
        }
    }
}
