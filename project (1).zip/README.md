# Food Ordering System (Java + DSA)

A console-based food ordering app built to showcase core data structures
and algorithms in a realistic setting.

## How to run

```
javac *.java
java Main
```

(Needs a JDK — `javac` — not just a JRE. Tested against Java 17+.)

## Project structure

| File | Role |
|---|---|
| `FoodItem.java` | Menu item model |
| `Order.java` | Order model, `Comparable` for priority queue ordering |
| `TrieNode.java` / `Trie.java` | Prefix-search tree for food-name autocomplete |
| `MenuManager.java` | Menu storage + sorting + searching |
| `Cart.java` | Shopping cart with undo |
| `OrderProcessor.java` | Kitchen order pipeline |
| `Main.java` | Console UI tying it all together |

## DSA concepts and where they live

| Concept | Where | Why it's used |
|---|---|---|
| **HashMap** | `MenuManager.menuById` | O(1) average lookup of a menu item by id |
| **Trie** | `Trie.java`, used in `MenuManager` | Fast prefix search / autocomplete on food names — O(length of prefix) instead of scanning the whole menu |
| **Merge Sort** (hand-written) | `MenuManager.mergeSort()` | Sort the menu by price or rating in O(n log n), guaranteed stable |
| **Binary Search** (hand-written) | `MenuManager.binarySearchByMinPrice()` | Find the cheapest item at/above a target price in O(log n) on the price-sorted menu |
| **ArrayList + Stack (Deque)** | `Cart.java` | Cart items stored in order; a stack tracks additions so "undo last add" is O(1) |
| **Priority Queue** | `OrderProcessor.pending` | Kitchen always serves the highest-priority order next — express orders jump ahead, otherwise FIFO by placement time (via `Order.compareTo`) |
| **Queue (LinkedList)** | `OrderProcessor.completed` | Keeps completed-order history in FIFO order |

## Suggested extensions (good for a viva / report)

- Swap the hand-written merge sort for a **quick sort** and compare performance on large menus.
- Add a **graph** for delivery-route optimization between restaurant and customer locations (Dijkstra/A*).
- Add a **min-heap** for "estimated prep time" instead of pure FIFO within a priority tier.
- Persist menu/orders to a file or simple database instead of in-memory storage.
- Add unit tests (JUnit) for `MenuManager`, `Cart`, and `OrderProcessor`.

## Sample flow

1. `1` → view the seeded menu (10 items across pizza, burgers, rice, dessert, etc.)
2. `2` → type `pa` to autocomplete "Paneer Tikka Burger"
3. `3` → sort by price or rating
4. `5` → add a couple of item ids (e.g. `F1`, `F6`) to the cart
5. `8` → checkout, choose express or not
6. `9` → kitchen processes the next order (priority queue in action)
7. `10` → see what's still pending, in priority order
