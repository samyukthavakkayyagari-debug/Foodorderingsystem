import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * OrderProcessor - manages the kitchen's order pipeline.
 *  - PriorityQueue<Order> handles ALL incoming orders, ordered by
 *    Order.compareTo(): express orders first, then FIFO by placement time.
 *  - A separate LinkedList (Queue) keeps the full history of completed orders.
 */
public class OrderProcessor {
    private final PriorityQueue<Order> pending = new PriorityQueue<>();
    private final Queue<Order> completed = new LinkedList<>();

    public void placeOrder(Order order) {
        pending.offer(order);
    }

    /** Kitchen picks up the next highest-priority order. */
    public Order processNext() {
        Order next = pending.poll();
        if (next != null) completed.offer(next);
        return next;
    }

    public boolean hasPending() {
        return !pending.isEmpty();
    }

    public int pendingCount() {
        return pending.size();
    }

    public List<Order> peekPendingOrder() {
        return List.copyOf(pending);
    }

    public List<Order> getCompletedHistory() {
        return List.copyOf(completed);
    }
}
