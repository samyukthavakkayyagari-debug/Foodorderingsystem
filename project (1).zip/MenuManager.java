import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * MenuManager - owns the restaurant menu and demonstrates:
 *  - HashMap for O(1) lookup by id
 *  - Trie for prefix search / autocomplete by name
 *  - Custom Merge Sort for sorting by price or rating
 *  - Binary Search for locating items in a price-sorted list
 */
public class MenuManager {
    private final Map<String, FoodItem> menuById = new HashMap<>();
    private final List<FoodItem> menuList = new ArrayList<>();
    private final Trie nameTrie = new Trie();

    public void addItem(FoodItem item) {
        menuById.put(item.getId(), item);
        menuList.add(item);
        nameTrie.insert(item.getName());
    }

    public FoodItem getById(String id) {
        return menuById.get(id); // O(1) average
    }

    public List<FoodItem> getAll() {
        return new ArrayList<>(menuList);
    }

    public List<String> autocomplete(String prefix) {
        return nameTrie.searchByPrefix(prefix);
    }

    // ---------- Merge Sort (O(n log n)) ----------
    public List<FoodItem> sortedByPrice() {
        List<FoodItem> copy = new ArrayList<>(menuList);
        mergeSort(copy, Comparator.comparingDouble(FoodItem::getPrice));
        return copy;
    }

    public List<FoodItem> sortedByRating() {
        List<FoodItem> copy = new ArrayList<>(menuList);
        mergeSort(copy, Comparator.comparingDouble(FoodItem::getRating).reversed());
        return copy;
    }

    private void mergeSort(List<FoodItem> list, Comparator<FoodItem> cmp) {
        if (list.size() <= 1) return;
        int mid = list.size() / 2;
        List<FoodItem> left = new ArrayList<>(list.subList(0, mid));
        List<FoodItem> right = new ArrayList<>(list.subList(mid, list.size()));
        mergeSort(left, cmp);
        mergeSort(right, cmp);
        merge(list, left, right, cmp);
    }

    private void merge(List<FoodItem> list, List<FoodItem> left, List<FoodItem> right, Comparator<FoodItem> cmp) {
        int i = 0, j = 0, k = 0;
        while (i < left.size() && j < right.size()) {
            if (cmp.compare(left.get(i), right.get(j)) <= 0) {
                list.set(k++, left.get(i++));
            } else {
                list.set(k++, right.get(j++));
            }
        }
        while (i < left.size()) list.set(k++, left.get(i++));
        while (j < right.size()) list.set(k++, right.get(j++));
    }

    // ---------- Binary Search (O(log n)) on a price-sorted list ----------
    /** Finds the first item whose price is >= targetPrice, or null if none. */
    public FoodItem binarySearchByMinPrice(double targetPrice) {
        List<FoodItem> sorted = sortedByPrice();
        int lo = 0, hi = sorted.size() - 1, result = -1;
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            if (sorted.get(mid).getPrice() >= targetPrice) {
                result = mid;
                hi = mid - 1;
            } else {
                lo = mid + 1;
            }
        }
        return result == -1 ? null : sorted.get(result);
    }
}
